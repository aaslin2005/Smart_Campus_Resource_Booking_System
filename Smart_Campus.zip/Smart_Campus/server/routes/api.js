const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const resourceController = require('../controllers/resourceController');
const bookingController = require('../controllers/bookingController');

// Auth routes
router.post('/register', authController.register);
router.post('/login', authController.login);

// Resource routes
router.get('/resources', resourceController.getResources);

// Booking routes
router.post('/book', bookingController.createBooking);
router.get('/bookings/:userId', bookingController.getUserBookings);
router.delete('/cancel/:id', bookingController.cancelBooking);

module.exports = router;