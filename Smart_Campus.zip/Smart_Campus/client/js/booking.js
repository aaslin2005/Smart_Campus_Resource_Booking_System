const API_BASE_URL = 'http://localhost:3000/api';

let currentUser = null;
let resources = [];

document.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const userId = localStorage.getItem('userId');
  const userName = localStorage.getItem('userName');

  if (!userId) {
    window.location.href = '/login.html';
    return;
  }

  currentUser = {
    id: userId,
    name: userName
  };

  document.getElementById('userName').textContent = `Welcome, ${userName}!`;

  // Load resources and bookings
  loadResources();
  loadUserBookings();

  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('bookingDate').min = today;

  // Handle booking form
  document.getElementById('bookingForm').addEventListener('submit', handleBooking);
});

async function loadResources() {
  try {
    const response = await fetch(`${API_BASE_URL}/resources`);
    const data = await response.json();
    resources = data.resources;

    // Populate resources grid
    const resourcesList = document.getElementById('resourcesList');
    resourcesList.innerHTML = '';

    resources.forEach(resource => {
      const card = document.createElement('div');
      card.className = 'resource-card';
      card.innerHTML = `
        <div class="resource-icon">
          ${getResourceIcon(resource.resource_type)}
        </div>
        <h4>${resource.name}</h4>
        <div class="resource-type">${resource.resource_type}</div>
        <p class="resource-info"><strong>Location:</strong> ${resource.location}</p>
        <p class="resource-info"><strong>Capacity:</strong> ${resource.capacity} people</p>
        <p class="resource-info">${resource.description}</p>
      `;
      resourcesList.appendChild(card);
    });

    // Populate dropdown
    const select = document.getElementById('resourceSelect');
    select.innerHTML = '<option value="">Choose a resource...</option>';
    resources.forEach(resource => {
      const option = document.createElement('option');
      option.value = resource.id;
      option.textContent = resource.name;
      select.appendChild(option);
    });
  } catch (error) {
    console.error('Error loading resources:', error);
    showBookingMessage('Failed to load resources', 'error');
  }
}

async function loadUserBookings() {
  try {
    const response = await fetch(`${API_BASE_URL}/bookings/${currentUser.id}`);
    const data = await response.json();
    const bookings = data.bookings;

    const bookingsList = document.getElementById('bookingsList');
    bookingsList.innerHTML = '';

    if (bookings.length === 0) {
      bookingsList.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📭</div>
          <p>No bookings yet. Book a resource to get started!</p>
        </div>
      `;
      return;
    }

    bookings.forEach(booking => {
      const card = document.createElement('div');
      card.className = `booking-card ${booking.status}`;
      const bookingDate = new Date(booking.booking_date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
      card.innerHTML = `
        <div class="booking-info">
          <div class="booking-resource">📍 ${booking.resource_name}</div>
          <div class="booking-time">⏰ ${booking.start_time} - ${booking.end_time}</div>
          <div class="booking-location">📅 ${bookingDate}</div>
          <div class="booking-location">📌 ${booking.location}</div>
          <div class="booking-status ${booking.status}">${booking.status.toUpperCase()}</div>
        </div>
        <div class="booking-actions">
          ${
            booking.status === 'confirmed'
              ? `<button onclick="cancelBooking(${booking.id})" class="btn btn-danger btn-small">Cancel</button>`
              : ''
          }
        </div>
      `;
      bookingsList.appendChild(card);
    });
  } catch (error) {
    console.error('Error loading bookings:', error);
  }
}

async function handleBooking(e) {
  e.preventDefault();

  const resourceId = document.getElementById('resourceSelect').value;
  const bookingDate = document.getElementById('bookingDate').value;
  const startTime = document.getElementById('startTime').value;
  const endTime = document.getElementById('endTime').value;

  if (!resourceId || !bookingDate || !startTime || !endTime) {
    showBookingMessage('All fields are required', 'error');
    return;
  }

  if (startTime >= endTime) {
    showBookingMessage('End time must be after start time', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/book`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: parseInt(currentUser.id),
        resourceId: parseInt(resourceId),
        bookingDate,
        startTime,
        endTime
      })
    });

    const data = await response.json();

    if (response.ok) {
      showBookingMessage('Booking confirmed successfully! 🎉', 'success');
      document.getElementById('bookingForm').reset();

      // Reload bookings after 1 second
      setTimeout(() => {
        loadUserBookings();
      }, 1000);
    } else {
      showBookingMessage(data.error || 'Booking failed', 'error');
    }
  } catch (error) {
    console.error('Error creating booking:', error);
    showBookingMessage('Network error. Please try again.', 'error');
  }
}

async function cancelBooking(bookingId) {
  if (!confirm('Are you sure you want to cancel this booking?')) {
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/cancel/${bookingId}`, {
      method: 'DELETE'
    });

    const data = await response.json();

    if (response.ok) {
      showBookingMessage('Booking cancelled successfully', 'success');
      loadUserBookings();
    } else {
      showBookingMessage(data.error || 'Cancellation failed', 'error');
    }
  } catch (error) {
    console.error('Error cancelling booking:', error);
    showBookingMessage('Network error. Please try again.', 'error');
  }
}

function showBookingMessage(message, type) {
  const messageDiv = document.getElementById('bookingMessage');
  messageDiv.textContent = message;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';

  // Auto-hide success messages after 4 seconds
  if (type === 'success') {
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 4000);
  }
}

function getResourceIcon(type) {
  const icons = {
    Lab: '🖥️',
    Room: '📋',
    'Sport Facility': '🏀',
    'Study Room': '📖',
    Hall: '🏛️'
  };
  return icons[type] || '📚';
}

function logout() {
  localStorage.clear();
  window.location.href = '/index.html';
}