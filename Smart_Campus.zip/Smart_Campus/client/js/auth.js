const API_BASE_URL = 'http://localhost:3000/api';

let isLoginMode = true;

// Check URL parameters on page load
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  if (params.get('mode') === 'register') {
    toggleAuthMode(null);
  }

  document.getElementById('authForm').addEventListener('submit', handleAuthSubmit);
});

function toggleAuthMode(event) {
  if (event) event.preventDefault();

  isLoginMode = !isLoginMode;
  const form = document.getElementById('authForm');
  const title = document.getElementById('authTitle');
  const submitBtn = document.getElementById('submitBtn');
  const registerFields = document.getElementById('registerFields');
  const toggleAuthDiv = document.getElementById('toggleAuth');

  if (isLoginMode) {
    title.textContent = 'Login';
    submitBtn.textContent = 'Login';
    registerFields.style.display = 'none';
    toggleAuthDiv.innerHTML =
      "Don't have an account? <a href='#' onclick='toggleAuthMode(event)'>Register here</a>";
  } else {
    title.textContent = 'Register';
    submitBtn.textContent = 'Register';
    registerFields.style.display = 'block';
    toggleAuthDiv.innerHTML =
      "Already have an account? <a href='#' onclick='toggleAuthMode(event)'>Login here</a>";
  }

  // Clear form
  form.reset();
  clearMessage();
}

async function handleAuthSubmit(e) {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const endpoint = isLoginMode ? '/login' : '/register';
  const payload = {
    email,
    password
  };

  if (!isLoginMode) {
    const fullName = document.getElementById('fullName').value;
    if (!fullName) {
      showMessage('Full name is required', 'error');
      return;
    }
    payload.fullName = fullName;
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (response.ok) {
      // Store user data in localStorage
      localStorage.setItem('userId', data.user.id);
      localStorage.setItem('userName', data.user.fullName);
      localStorage.setItem('userEmail', data.user.email);

      showMessage(data.message, 'success');

      // Redirect to dashboard after 1 second
      setTimeout(() => {
        window.location.href = '/dashboard.html';
      }, 1000);
    } else {
      showMessage(data.error || 'An error occurred', 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showMessage('Network error. Please try again.', 'error');
  }
}

function showMessage(message, type) {
  const messageDiv = document.getElementById('message');
  messageDiv.textContent = message;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';
}

function clearMessage() {
  const messageDiv = document.getElementById('message');
  messageDiv.textContent = '';
  messageDiv.className = 'message';
  messageDiv.style.display = 'none';
}